from networkx import Graph
from networkx import read_graph6, to_graph6_bytes
import subprocess

INPUT_FILE = 'test2input.g6'

graph = Graph()

graph.add_edge(0, 4)
graph.add_edge(0, 3)
graph.add_edge(1, 2)
graph.add_edge(2, 3)


def has_ind_set_k(graph, k):
    
    # write graph to file in graph6 format
    with open(INPUT_FILE, 'wb') as f:
        f.write(to_graph6_bytes(graph, header=False))

    f.close()

    # call countg with constraint -h{k}
    # here to count of maximal ind set of k
    res = subprocess.run(['./countg', f'-h{k}', INPUT_FILE], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    return res.stdout.decode('ascii')[1] == '1'



# # read graphs from output file
# graphs = read_graph6(OUTPUT_FILE)

# def has_ind_set(graph, k, set_nodes, count):

#     if count == k and len(set_nodes) <= k:
#         if len(set_nodes) == k:
#             return True
#         elif len(set_nodes) < k:
#             return False
#     else:
#         for node in set_nodes:
#             set_nodes = set_nodes - set(graph.neighbors(node)) - {node}
#             count += 1
#             return has_ind_set(graph, k, set_nodes, count)

# def choose_sublists(lst, k):
#     if len(lst) == k:
#         return [lst]
#     if  k == 0:
#         return [[]]
#     if k == 1:
#         return [[i] for i in lst]
#     sub_lst1=choose_sublists(lst[1:], k-1)
#     for i in sub_lst1:
#         i.append(lst[0])
#     sub_lst2=choose_sublists(lst[1:], k)
#     final_lst=[]
#     final_lst.extend(sub_lst1)
#     final_lst.extend(sub_lst2)
#     return final_lst

# def check(graph, nodes):
     
#     for i in range(len(nodes)):
#         for j in range(i + 1, len(nodes)):
             
#             if graph.has_edge(nodes[i], nodes[j]):
#                 return False
                 
#     return True  


# def has_ind_set_k(graph, k):
#     all_sub_k = choose_sublists(list(graph.nodes), k)
#     for sub_k in all_sub_k:
#         if check(graph, sub_k):
#             return True
#     return False
