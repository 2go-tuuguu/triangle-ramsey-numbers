from networkx import Graph, read_graph6, to_graph6_bytes
import subprocess

# g = Graph([(0, 1)])

g1 = Graph([(0, 1), (0, 3), (2, 3)])
g2 = Graph([(0, 3), (1, 2), (2, 3)])
g3 = Graph([(0, 1), (1, 2), (2, 3)])
g4 = Graph([(0, 1), (0, 3), (1, 2)])

graphs = [g1, g2, g3, g4]

with open('test.g6', 'wb') as f:
    for g in graphs:
        f.write(to_graph6_bytes(g, header=False))

subprocess.run(['./shortg','-g','test.g6','output.g6'], stderr=subprocess.DEVNULL)

gs = read_graph6('output.g6')
if isinstance(gs, list):
    for g in gs:
        print(g)
else:
    print(gs)

# for i in range(gs.number_of_nodes()):
#     for j in range(gs.number_of_nodes()):
#         if gs.has_edge(i, j):
#             print(1, end=' ')
#         else:
#             print(0, end=' ')
#     print()