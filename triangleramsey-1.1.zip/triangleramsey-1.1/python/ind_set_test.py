from networkx import Graph

graph = Graph()

# has ind set 3
# graph.add_edge(0, 4)
# graph.add_edge(0, 3)
# graph.add_edge(1, 2)
# graph.add_edge(2, 3)

# has ind set 4
# graph.add_edge(0, 1)
# graph.add_edge(1, 2)
# graph.add_edge(1, 3)
# graph.add_edge(1, 4)

# has ind set 2
graph.add_edge(0, 1)
graph.add_edge(1, 2)
graph.add_edge(2, 3)
graph.add_edge(0, 3)

def choose_sublists(lst, k):
    if len(lst) == k:
        return [lst] 
    if  k == 0:
        return [[]]
    if k == 1:
        return [[i] for i in lst]
    sub_lst1=choose_sublists(lst[1:], k-1)
    for i in sub_lst1:
        i.append(lst[0])
    sub_lst2=choose_sublists(lst[1:], k)
    final_lst=[]
    final_lst.extend(sub_lst1)
    final_lst.extend(sub_lst2)
    return final_lst

def check_for_ind(graph, ind_nodes, new_nodes):
    for i in ind_nodes:
        for n in new_nodes:
            if graph.has_edge(i, n):
                return False
    return True

def extract_elements(lst):
    return list(map(lambda el:[el], lst))


def had_ind_set(graph, k, nodes_incl_set, prev_nodes_set):

    if k == 1:
        return False

    if len(nodes_incl_set) == 0:
        sublists = choose_sublists(list(graph.nodes), k)
        for sub in sublists:
            if check_for_ind(graph, sub, sub):
                return True
        return False
    else:
        if not check_for_ind(graph, nodes_incl_set, nodes_incl_set):
            return False

        other_nodes = set(graph.nodes) - nodes_incl_set
        other_k = k - len(nodes_incl_set)

        if other_k == 1:
            sublists = extract_elements(other_nodes)
        elif other_k == 0:
            sublists = []
        else:
            sublists = choose_sublists(list(other_nodes), other_k)

        if sublists:
            for sub in sublists:
                if check_for_ind(graph, nodes_incl_set, sub):
                    return True
            return False
        else:
            return False


print(had_ind_set(graph, 2, set(), set()))
