class Graph(object):

    # Initialize the matrix
    def __init__(self, size):
        self.adjMatrix = []
        for i in range(size):
            self.adjMatrix.append([0 for i in range(size)])
        self.size = size

    # Add edges
    def add_edge(self, v1, v2):
        if v1 == v2:
            print("Same vertex %d and %d" % (v1, v2))
        self.adjMatrix[v1][v2] = 1
        self.adjMatrix[v2][v1] = 1

    # Remove edges
    def remove_edge(self, v1, v2):
        if self.adjMatrix[v1][v2] == 0:
            print("No edge between %d and %d" % (v1, v2))
            return
        self.adjMatrix[v1][v2] = 0
        self.adjMatrix[v2][v1] = 0

    def remove_vertex(self, v):
        if self.has_vertex(v):
            # removing the vertex
          while(v < self.size - 1):
         
             # shifting columns to left
             for i in range(0, self.size):
                  self.adjMatrix[i][v]= self.adjMatrix[i][v + 1]
            
             # shifting rows up
             for i in range(0, self.size):
                  self.adjMatrix[v][i]= self.adjMatrix[v + 1][i]

             v += 1
 
          # decreasing the number of vertices
          self.size = self.size - 1

    def remove_vertex_with_neighbors(self, v):
        arr = [v]
        for i in range(self.size):
            if (self.has_edge(v, i)):
                arr.append(i)

        arr.sort(reverse=True)

        for i in arr:
            self.remove_vertex(i)


    def has_vertex(self, v):
        return self.size > v

    def has_edge(self, v1, v2):
        return self.adjMatrix[v1][v2] == 1

    def get_edge_count(self):
        count = 0
        for i in range(self.size):
            for j in range(self.size):
                count += self.adjMatrix[i][j]
        return int(count / 2)

    def __len__(self):
        return self.size

    # Print the matrix
    def print_matrix(self):
        for i in range(self.size):
            for j in range(self.size):
                print('{:2}'.format(self.adjMatrix[i][j]), end='')
            print()

