import copy
from Graph import Graph

def get_all_one_edge_removed(graph, size):
    result = []
    for i in range(size):
        for j in range(i, size):
            if (graph.has_edge(i, j)):
                graph.remove_edge(i, j)
                temp = copy.deepcopy(graph)
                result.append(temp)
                graph.add_edge(i, j)
    return result

# # Function to check if graph has an independent set of order k
# def has_ind_set_k(graph, k):
#     if graph.__len__() < k:
#         # graphs can't  have an ind set of k 
#         # if it has less than k vertices
#         return False
#     elif graph.__len__() == k:
#         # graph with k vertices has ind set of k 
#         # if and only if it has no edges
#         return graph.get_edge_count() == 0
#     elif k == 2 and graph.get_edge_count() != 1:
#         # graph has a ind set of 2 if and only if 
#         # number of vertices are greater than number of edges
#         return graph.__len__() > graph.get_edge_count()
#     elif graph.__len__() > 0:
#         graph.remove_vertex_with_neighbors(0)
#         return has_ind_set_k(graph, k - 1)


# Python3 code to check if a given graph
# contains an independent set of size k
 
# Function to construct a set of given size k
def has_ind_set_k(graph, arr, k, index, sol):
     
    # Check if the selected set is independent or not.
    # Change the value of sol to True and return
    # if it is independent
    if k == 0:
        if check(graph, arr) == True:
            sol[0] = True
            return
         
    else:
        # Set of size k can be formed even if we don't
        # include the vertex at current index.
        if index >= k:
            return (has_ind_set_k(graph, arr[:] + [index], k-1, index-1, sol) or
                    has_ind_set_k(graph, arr[:], k, index-1, sol))
         
        # Set of size k cannot be formed if we don't
        # include the vertex at current index.
        else:
            return has_ind_set_k(graph, arr[:] + [index], k-1, index-1, sol)
 
# Function to check if the given set is
# independent or not
# arr --> set of size k (contains the
# index of included vertex)
def check(graph, arr):
     
    # Check if each vertex is connected to any other
    # vertex in the set or not
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
             
            if graph.has_edge(arr[i],arr[j]):
                return False
                 
    return True

# Function to check if graph has an independent set of order k
def has_ind_set_k(graph, k):
    if graph.__len__() < k:
        # graphs can't  have an ind set of k 
        # if it has less than k vertices
        return False
    elif graph.__len__() == k:
        # graph with k vertices has ind set of k 
        # if and only if it has no edges
        return graph.get_edge_count() == 0
    elif k == 2 and graph.get_edge_count() != 1:
        # graph has a ind set of 2 if and only if 
        # number of vertices are greater than number of edges
        return graph.__len__() > graph.get_edge_count()
    elif graph.__len__() > 0:
        graph.remove_vertex_with_neighbors(0)
        return has_ind_set_k(graph, k - 1)
        

g = Graph(5)
g.add_edge(0, 3)
g.add_edge(0, 4)
g.add_edge(1, 2)
g.add_edge(2, 3)





# g.print_matrix()
# print()

# g.remove_vertex_with_neighbors(0)

g.print_matrix()
print()

print(has_ind_set_k(g, 3))


# graphs = set()

# g1 = Graph(4)
# g1.add_edge(1, 0)
# graphs.add(g1)
# print(graphs)
# print(g1 in graphs)

# g2 = Graph(4)
# g2.add_edge(1, 0)
# graphs.add(g2)
# print(graphs)
# print(g2 in graphs)

# g3 = Graph(4)
# g3.add_edge(2, 3)
# graphs.add(g3)
# print(graphs)
# print(g1 in graphs)